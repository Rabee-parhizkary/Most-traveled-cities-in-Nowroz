import os
import csv
directory = "1400"
os.makedirs("1400_Daily")
csv_files = [file for file in os.listdir(directory) if file.endswith('.csv')]
cities = {}
for file in csv_files :
    file = open(directory+"/"+file)
    spam_Reader = csv.DictReader(file)
    
    for data in spam_Reader:
        # print(data)
        
        # spam_writer = csv.DictWriter(new_file , spam_Reader.fieldnames)
        
            new_file = open("1400_Daily/"+data["City"]+".csv" , "w")
            cities.setdefault(data["City"] , [])
        # spam_writer.writeheader()
        # spam_writer.writerow(data)

# print(cities)

for file in csv_files :
    file = open(directory+"/"+file)
    spam_Reader = csv.DictReader(file)
    header = spam_Reader.fieldnames
    for data in spam_Reader:
        # if data["Province"] == "Golestan" :
         cities[data["City"]].append(data["Net"])
        
for city in cities:
    file_path = f'1400_Daily/{city}.csv'  # Adjust the file path accordingly
    with open(file_path, 'w', newline='') as file2:  # Open the file in write mode
        spam_writer = csv.DictWriter(file2, fieldnames=header)  # Assuming header is defined
        spam_writer.writeheader()  # Write header if necessary
        for filename in csv_files:
            file_path = os.path.join(directory, filename)  # Construct full file path
            with open(file_path, 'r') as file:  # Open file in read mode
                spam_reader = csv.DictReader(file)
                for data in spam_reader:
                    if data["City"] == city :
                        spam_writer.writerow(data)  # Write data to the CSV file


# print(cities['Sari'] , len(cities['Sari']))


   