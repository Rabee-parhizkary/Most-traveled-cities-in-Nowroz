import matplotlib.pyplot as plt
import seaborn as sns
import json

# List of data files for different years
files = ["1400results.json", "1401results.json"]

# Seaborn style settings
sns.set_style("whitegrid")

# Create the chart
plt.figure(figsize=(12, 6))

# Column layout
ax = plt.subplot(111)

# For each year
for i, file in enumerate(files, start=1400):
    # City and tourist data from JSON files
    with open(file) as f:
        cities_data = json.load(f)
        cities_data = dict(sorted(cities_data.items() , key= lambda x : x[0]))
    cities = list(cities_data.keys())[:15]  # Using the first 15 cities
    tourists = list(cities_data.values())[:15]  # Using tourist numbers for the first 15 cities
    
    # Plotting the bar chart for each year with different colors
    sns.barplot(x=cities, y=tourists, ax=ax, alpha=0.7, label=f"Year {i}")

# Other chart settings
plt.xlabel('Cities', fontsize=14, fontweight='bold', fontfamily='Book Antiqua', ha='right')
plt.ylabel('Tourists Count', fontsize=14, fontweight='bold', fontfamily='Book Antiqua', ha='right')
plt.title('Tourists Count in Different Years', fontsize=16, fontweight='bold', fontfamily='Book Antiqua', ha='right')
plt.xticks(fontsize=12, fontweight='normal', fontfamily='Book Antiqua', rotation=45, ha='right')
plt.yticks(fontsize=12, fontweight='normal', fontfamily='Book Antiqua')

# Inverting city names
ax.invert_xaxis()

# Save the chart as a PNG file
plt.savefig('tourists_bar_chart.png', dpi=300)

# Show the chart
plt.tight_layout()
plt.legend()
plt.show()
