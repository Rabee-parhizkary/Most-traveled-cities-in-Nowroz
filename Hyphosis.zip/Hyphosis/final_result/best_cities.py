import json
cities_1400 = {}
cities_1401 = {}
cities_1402 = {}

file = open("1400results.json")
cities_1400 = json.load(file)
cities_1400 = dict(list(cities_1400.items())[:10])
file = open("1401results.json")
cities_1401 = json.load(file)
cities_1401 = dict(list(cities_1401.items())[:10])
file = open("1402results.json")
cities_1402 = json.load(file)
cities_1402 = dict(list(cities_1402.items())[:10])

file = open("1400tourists.json")
t_1400 = json.load(file)
file = open("1401tourists.json")
t_1401 = json.load(file)
file = open("1402tourists.json")
t_1402 = json.load(file)
print(cities_1400)
print("__________")
# print(t_1401)

best_cities = {**cities_1400,**cities_1401 ,**cities_1402}
print(best_cities)
result = {}
for city in best_cities:
    result.setdefault(city , round((t_1400[city]*29 + t_1401[city]*23 + t_1402[city]*29)/(29*2+23)))
result = dict(sorted(result.items() , key = lambda x : x[1]  , reverse = True))
file = open('TopCities.json' , 'w')
json.dump(result , file , indent = 6)
print(result)


