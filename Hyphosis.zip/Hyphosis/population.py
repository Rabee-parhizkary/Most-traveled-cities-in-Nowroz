import pandas as pd

# Read CSV file containing Persian and English translations
translation_df = pd.read_csv("city-translation.csv")

# Read Excel file containing Persian words and population
population_df = pd.read_excel("95.xlsx")
# print(translation_df.columns.values)

# Create dictionaries to store translations and populations
translation_dict = dict(zip(translation_df['Persian'], translation_df['English']))
population_dict = dict(zip(population_df.iloc[:, 4], population_df.iloc[:,6]))
# print(translation_dict)
# print(population_dict)

# Create a dictionary to store English words and their corresponding populations
english_population_dict = {}

# Iterate through the English words and find their corresponding population
for persian_word, english_word in translation_dict.items():
    if persian_word in population_dict:
        english_population_dict[english_word] = population_dict[persian_word]

# Print the dictionary containing English words and their populations
import json
with open("population.json" , "w") as file:
    json.dump(english_population_dict,file , indent = 6)
print(json.dumps(english_population_dict , indent=6))
# print(english_population_dict)
