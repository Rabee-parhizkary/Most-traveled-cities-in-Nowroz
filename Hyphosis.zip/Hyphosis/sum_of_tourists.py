import os
import csv
import json
for i in range(3) :
    cities = {}
    directory = f'140{i}_Daily'
    files =  [file for file in os.listdir(directory) if file.endswith('.csv')]
    for file in files : 
        avg = 0
        file = open(directory + '/' +file)
        spam_reader = csv.DictReader(file)
        for data in spam_reader:
            if int(data['Net']) > 0 :
              avg += int(data['Net'])
        cities.setdefault(file.name.split('.')[0].split('/')[1] , avg)
    file = open("final_result"+ '/' + f'140{i}tourists.json' , 'w')
    json.dump(cities , file , indent=4)
    print(f"140{i}")
    print(cities)
        
