import csv
import numpy as np
import os
from math import sqrt
from scipy.stats import t

values_year = {"1400":{} , "1401" : {} , "1402" : {}}
import json
file = open('population.json')
data = json.load(file)
data = dict(sorted(data.items(), key=lambda x: x[0]))

def file_Reader(year) :
    directory = f'{year}_Daily'
    files = os.listdir(directory)
    cities_to_del = ["Golestan Forest"  , "Gilan Border" ,"Imamzadeh Hashem Tehran" , "Kandovan" , "Sisangan" , "Park Jangali" , "Se-rah-e Kalaleh" , "Shahroud"  ,"Ghazvin" , "Semnan" ]
    for c in cities_to_del :
       try :
         os.remove(directory+"/"+f"{c}.csv")
       except :
          pass
    file_names = [os.path.splitext(file)[0] for file in files if file.endswith('.csv')]
    return file_names

def t_test_values(city , year):
    city_values = []
    file = open(f"{year}_Daily/"+city+".csv")
    spam_Reader = csv.DictReader(file)
    for d in spam_Reader:
        pop = data[city]
        nesbat = int(d['Net'])/pop
        if nesbat > 0:
         city_values.append(nesbat)
        else:
           city_values.append(0) 
    values_year[year].setdefault(city , city_values)
from golestan02Data import golestanData1402
g_02 = golestanData1402()
# print(g_02)
for d in g_02 :
#    print(d , g_02.get(d))
   datas = [int(net)/data[d] for net in g_02[d] ]
#    print(d , datas)
   values_year['1402'].setdefault(d , datas)

#Read Population data


years = ['1400' , '1401' , '1402']
for y in years : 
    file_names = file_Reader(y)
    for city in file_names:
      t_test_values(city , y)

# print(values_year["1400"])
for year in values_year : 
   values_year[year] = dict(sorted(values_year[year].items() , key = lambda x : x[0]))
file = open('nets/1402.json' ,'w')
json.dump(values_year['1402'] , file , indent=4)
# print(values_year)
# print(json.dumps(values_year['1402'] ,indent=6))
# values =dict(sorted(values.items(), key=lambda x: x[0]))






# print(data)
# print(data)

# print("data:")
# print(data)
# print("*"*60)
# print("value:")
# print(values)
# print("*"*60)

# file_names.remove("Gonabad")

# for c in file_names :
#     if c not in data:
#         print(c)
# print(values)
def T_Test(city , year) :
    mean = np.mean(values_year[year][city])
    variance = np.var(values_year[year][city])
    return mean , variance


#set an average
# c = [city for city in values_year["1401"] if values_year['1401'][city].count(0) < int(len(values_year['1401'][city])/2)]
c = [city for city in data if data[city] > 50000]
sum_avg=0
for city in c :
   sum_avg += T_Test(city , '1400')[0]

print("d"  , sum_avg/len(c))
   
print((0.0313 * 29 + 0.0367 * 23 + 0.02836*29 ) /(29 + 23 + 29))
avg_mu = {"1400" : {} , "1401" : {}, "1402" : {}}
def calc_avg_mu(year):
   for city in file_names :
        x , var = T_Test(city ,year)
        # print(x , var)
        df = len(values_year[year][city]) 
        confidence_level = 0.95
        t_value = t.ppf(confidence_level, df)
        # print(t_value)
        # avg_mu[year] = mu
        if var!=0 : 
         shakhes = (x - 0.032) / (var / sqrt(df+1))
        else:
           shakhes = 0

        if shakhes > t_value:
         avg_mu[year].update({city :shakhes })

        # print("shakhes: " , shakhes , city)
calc_avg_mu("1400")
calc_avg_mu("1401")
calc_avg_mu("1402")
avg_mu['1400'] = dict(sorted(avg_mu['1400'].items() , key = lambda x : x[1] , reverse= True))
avg_mu['1401'] = dict(sorted(avg_mu['1401'].items() , key = lambda x : x[1] , reverse= True))
avg_mu['1402'] = dict(sorted(avg_mu['1402'].items() , key = lambda x : x[1] , reverse= True))
for i in range(0 , 3) :
   file = open('final_result/'+f"140{i}results.json" , 'w')
   json.dump(avg_mu[f'140{i}'] , file ,  indent = 4)
# print(avg_mu['1400'])
# print("_"*50)
# print(avg_mu['1401'])
# print("_"*50)
# print(avg_mu['1402'])

# print(avg_mu , sum(avg_mu.values())/3)
# print((0.6331837377219017 + 0.8671478418848615 + 0.9815491777632639)/3 )
# print(( 0.8684750058814664 + 1.2812924346399435 + 0.507919142563002)/3 )
# print((1.4790871392884697 + 2.271384993142794 + 1.4790871392884697)/3)
# print(1.7081516851747973)

