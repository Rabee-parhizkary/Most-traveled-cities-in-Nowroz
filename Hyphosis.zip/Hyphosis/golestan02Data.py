import csv , os , pandas as pd
def golestanData1402():
    global new_directory
    golestan_1402 = {}
    directory_1401 = '1401_Daily_Golestan'
    directory_1400 = '1400_Daily_Golestan'
    new_directory = "1402_Golestan_avg"
    os.makedirs(new_directory , exist_ok=True)
    files_1400 = [file for file in os.listdir(directory_1400) if file.endswith('.csv')]
    files_1401 = [file for file in os.listdir(directory_1401) if file.endswith('.csv')]
    files_1400.remove('Shahroud.csv')
    files_1401.remove('Shahroud.csv')
    files_1400.remove('Golestan Forest.csv')
    files_1401.remove('Golestan Forest.csv')
    files_1400.remove('Se-rah-e Kalaleh.csv')
    files_1401.remove('Se-rah-e Kalaleh.csv')

    for file_1400 , file_1401 in zip(files_1400 , files_1401):
       data = []
       file_1400 = open('1400_Daily_Golestan/' + file_1400)
       file_1401 = open('1401_Daily_Golestan/' + file_1401)
       spam_Reader_1400 = csv.DictReader(file_1400)
       spam_Reader_1401 = csv.DictReader(file_1401)
       for data_1400 , data_1401 in zip(spam_Reader_1400 , spam_Reader_1401):
           import time 
        #    time.sleep(1)
        #    print("1400: " , data_1400)
        #    print("1401: " , data_1401)
        #    print((int(data_1400['Net'])+int(data_1401['Net']))/2)
           data.append(round((int(data_1400['Net'])+int(data_1401['Net']))/2))
           
       golestan_1402.setdefault(file_1400.name.split('.')[0].split("/")[1] , data)
    # print(golestan_1402)
    return golestan_1402
       
# golestanData1402_convertTo_CSV()



# golestanData1402()